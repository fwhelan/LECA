LECA Network
============

Description of data files
-------------------------

The files represent the nodes and edges in the LECA network. They may be used as-is, for instance, used as an [Excel](https://products.office.com) spreadsheet or imported into network analysis tools such as [Gephi](https://gephi.org). Type information is included in the [CSV](https://en.wikipedia.org/wiki/Comma-separated_values) headers which makes these files appropriate for installation as a [Neo4j](https://neo4j.com/) database (see below).

### Nodes, in CSV format ###
* `node-Cluster.typed_csv` - cluster metadata
* `node-Gene.typed_csv` - LECA gene metadata
* `node-KeggGene.typed_csv` - KEGG gene metadata
* `node-KeggPathway.typed_csv` - KEGG pathway metadata

### Edges, in CSV format ###
* `edge-Cluster-CONTAINS-Gene.typed_csv` - cluster to LECA gene mapping
* `edge-Cluster-CONTAINS-KeggGene.typed_csv` - cluster to KEGG gene mapping
* `edge-KeggPathway-CONTAINS-KeggGene.typed_csv` - pathway to gene mapping

### Miscellaneous ###
* `import.sh` - neo4j import script
* `readme.md` - this file

Installation as a Neo4j database
--------------------------------

Please note:
* `import.sh` is written for UNIX, similar commands can be executed from the Windows Console, you will have to make the appropriate changes manually.
* Neo4j behaviour is subject to change, please see the current Neo4j documentation online for more details.


0. Please download and install the approproiate Neo4j database server for your system before continuing.
   See: https://neo4j.com
0. Open your terminal and navigate to this (the LECA network data) folder.
0. Modify the `import.sh` file so that the paths reflect your own.
   The variables must specify the location of the data and the Neo4j binaries on your system.
0. Run the `import.sh` file (i.e. `./import.sh`) to create the Neo4j database.
0. This will create a new database, called `leca.graphdb`.
   This should be placed in your `neo4j/data/databases` directory - you can then point your Neo4j server at this directory by making appropriate changes to `neo4j/conf/neo4j.conf` and restarting Neo4j.

The LECA data were exported and are usable by [BIO42](https://bitbucket.org/mjr129/bio42).

