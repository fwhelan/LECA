#
# SCRIPT AUTOMATICALLY GENERATED USING BIO42
# COMMAND: PARCEL_TO_DATABASE
#

# Set the following variables to your Neo4j path!
NEO4J_BINARIES="/Users/martinrusilowicz/xapps/neo4j/bin"

# Execute the current script from the data directory, or set the following variable to the location of the data to import
IMPORT_DIRECTORY="${PWD}"

# The import command itself
${NEO4J_BINARIES}/neo4j-import --into leca.graphdb --nodes:Cluster ${IMPORT_DIRECTORY}/node-Cluster.typed_csv --nodes:Gene ${IMPORT_DIRECTORY}/node-Gene.typed_csv --nodes:KeggGene ${IMPORT_DIRECTORY}/node-KeggGene.typed_csv --nodes:KeggPathway ${IMPORT_DIRECTORY}/node-KeggPathway.typed_csv --relationships:CONTAINS ${IMPORT_DIRECTORY}/edge-Cluster-CONTAINS-Gene.typed_csv --relationships:CONTAINS ${IMPORT_DIRECTORY}/edge-Cluster-CONTAINS-KeggGene.typed_csv --relationships:CONTAINS ${IMPORT_DIRECTORY}/edge-KeggPathway-CONTAINS-KeggGene.typed_csv --multiline-fields=true --array-delimiter TAB --skip-bad-relationships=true --skip-duplicate-nodes=true --bad-tolerance=100000000 --ignore-empty-strings=true
